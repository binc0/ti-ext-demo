<?php

return [
    'text_component_title' => 'Demo Component',
    'text_component_desc' => 'Component provided for demonstration',
];