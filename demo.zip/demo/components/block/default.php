<div class="well">
    <h3><?= $title ?></h3>
    <p>This is the default view for <?= ucwords($code) ?> Component</p>
</div>